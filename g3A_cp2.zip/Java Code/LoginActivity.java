package com.ugottime;

import android.support.annotation.MainThread;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.view.View;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import android.view.View.OnClickListener;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private Button goLog;
    private Button goSign;
    private String login_email;
    private String login_pass;

    private EditText emailText;
    private EditText passwordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailText = (EditText)findViewById(R.id.login_mail);
        passwordText = (EditText)findViewById(R.id.login_pw);
        goLog = (Button)findViewById(R.id.login_button);
        goSign =(Button)findViewById(R.id.log_sign_up_button);
        goLog.setOnClickListener(this);
        goSign.setOnClickListener(this);


    }

    public void userReg() {
        startActivity(new Intent(this,SignIn.class));
    }

    public void userLogin(View view)
    {


    }

    @Override
    public void onClick(View v) {
        if(v == goLog) {
            login_email = emailText.getText().toString();
            login_pass = passwordText.getText().toString();
            final String method = "login";
            BackgroundTask backgroundTask = new BackgroundTask(this);
            backgroundTask.execute(method, login_email, login_pass);
            if(backgroundTask.getAttemp() == true) {

            }
        }


        else if(v == goSign)
        {
            Intent intent = new Intent(LoginActivity.this, SignIn.class);
            startActivity(intent);
        }
    }
}




