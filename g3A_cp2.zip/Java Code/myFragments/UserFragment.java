package com.ugottime.myFragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.ugottime.MainUserPage;
import com.ugottime.MoreInformationPage;
import com.ugottime.R;

/**
 * Created by Kaan on 22.4.2016.
 */

    public class UserFragment extends Fragment implements View.OnClickListener{


    private Button goMore;
    private TextView name;
    private TextView surname;
    private TextView department;

        public UserFragment() {

        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            // Inflate the layout for this fragment
            View view = inflater.inflate(R.layout.fragment_user, container, false);

            name = (TextView)view.findViewById(R.id.name_Text);
            surname = (TextView)view.findViewById(R.id.surname_text);
            department = (TextView)view.findViewById(R.id.department_text);
            goMore = (Button)view.findViewById(R.id.user_more_ınfo_button);

            return view;

        }



    @Override
    public void onClick(View v) {
        if (v == goMore) {
            Intent intent = new Intent(getActivity(), MoreInformationPage.class);
            startActivity(intent);
        }
    }

    }



