package com.ugottime;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.support.v4.view.ViewPager;
import android.support.design.widget.TabLayout;
import android.content.Intent;
import android.widget.EditText;
import android.widget.TextView;

import com.ugottime.myFragments.UserFragment;
import com.ugottime.myFragments.fragment_schedule;

public class MainUserPage extends AppCompatActivity {
    Toolbar toolbar;
    TabLayout tabLayout;
    ViewPager viewPager;
    ViewPagerAdapter viewPagerAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_user_page);
        toolbar = (Toolbar)findViewById(R.id.userbar_layout);
        setSupportActionBar(toolbar);
        tabLayout = (TabLayout)findViewById(R.id.user_layout);
        viewPager = (ViewPager)findViewById(R.id.viewPager);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPagerAdapter.addFragments(new UserFragment(), "My Profile");
        viewPagerAdapter.addFragments(new fragment_schedule(), "My Schedule");
        viewPager.setAdapter(viewPagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
    };
    }

