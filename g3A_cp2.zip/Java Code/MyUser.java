package com.ugottime;

import java.util.ArrayList;

/**
 * Created by Kaan on 25.4.2016.
 */
public class MyUser {
    //Variable
    private int user_primary_key;
    private int user_schedule_primary_key;
    private String name;
    private String surname;
    private String email;
    private String department;
    private ArrayList<Integer> friendKey;
    private ArrayList<String> friendList;


    public MyUser(int primary_key, int schedule_primary_key)
    {
        this.user_primary_key = primary_key;
        this.user_schedule_primary_key = user_schedule_primary_key;
        this.name = "kaan";
        this.surname = "sancak";

    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public String getEmail() {
        return email;
    }
    public String getDepartment() {
        return department;
    }


}
