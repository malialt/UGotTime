package com.ugottime;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Kaan on 24.4.2016.
 */
public class BackgroundTask extends AsyncTask<String,Void,String> {

    private final String REG_URL = "http://ksdb.comlu.com/register.php";
    private final String LOG_URL = "http://ksdb.comlu.com/login.php";


    Context ctx;
    AlertDialog alertDialog;
    private boolean attemp = false;

    public BackgroundTask(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected String doInBackground(String... params) {
        String method = params[0];
        if (method.equals("register")) {
            final String user_name = params[1];
            final String user_surname = params[2];
            final String user_email = params[3];
            final String user_pw = params[4];
            final String user_repw = params[5];
            final String user_dp = params[6];


            try {
                URL url = new URL(REG_URL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream OS = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter =
                        new BufferedWriter(new OutputStreamWriter(OS, "UTF-8"));
                String data = URLEncoder.encode("u_name", "LATIN1") + "=" + URLEncoder.encode(user_name, "LATIN1") + "&"
                        + URLEncoder.encode("u_lname", "LATIN1") + "=" + URLEncoder.encode(user_surname, "LATIN1") + "&"
                        + URLEncoder.encode("u_email", "LATIN1") + "=" + URLEncoder.encode(user_email, "LATIN1") + "&"
                        + URLEncoder.encode("u_pw", "LATIN1") + "=" + URLEncoder.encode(user_pw, "LATIN1") + "&"
                        + URLEncoder.encode("u_dp", "LATIN1") + "=" + URLEncoder.encode(user_dp, "LATIN1");

                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                OS.close();
                InputStream IS = httpURLConnection.getInputStream();
                IS.close();
                return "Registration success";


            } catch (MalformedURLException e) {
                e.printStackTrace();
                ;
            } catch
                    (IOException e) {
                e.printStackTrace();
            }
        } else if (method.equals("login")) {
            final String u_email = params[1];
            final String u_pw = params[2];
            try {
                final URL url = new URL(LOG_URL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("u_email", "UTF-8") + "=" + URLEncoder.encode(u_email, "UTF-8") + "&" +
                        URLEncoder.encode("u_pw", "UTF-8") + "=" + URLEncoder.encode(u_pw, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();

                BufferedReader bufferedReader =
                        new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String response = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    response += line;
                }
                if(response.equals("Welcome"))
                    attemp = true;
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
            return null;

    }
    @Override
    protected void onPreExecute() {
        alertDialog = new AlertDialog.Builder(ctx).create();
        alertDialog.setTitle("Login Information...");
        if(attemp == true){
            Intent intent = new Intent(ctx.getApplicationContext(), MainUserPage.class);
            ctx.startActivity(intent);
        }

    }

    @Override
    protected void onPostExecute(String result) {
        if(attemp == true){
            Intent intent = new Intent(ctx.getApplicationContext(), MainUserPage.class);
            ctx.startActivity(intent);
            ((Activity)ctx).finish();
        }
        else
        {
            alertDialog.setMessage(result);
            alertDialog.show();

        }
    }


    public boolean getAttemp() {
        return attemp;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onCancelled(String aVoid) {
        super.onCancelled(aVoid);
    }


}
