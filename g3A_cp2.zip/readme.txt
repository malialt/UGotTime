Group Number: g3A

Title: UGotTime?

Description: We realized that arranging your time at Bilkent is very difficult because of the homeworks, exams, projects so we have decided to create an android application that helps Bilkent students to use their time more efficiently. With our application, UGotTime, students can see common free time with their friends and arrange events together. They can search for other students and they can connect with them.

Current Status: - We have complited the user interface. All xml contents are connected to activities. We also connected the database. We had tried some input and outputs. To do that we wrote some php scripts. In our current status, we can register new users and login to the application. However we are having difficulty in taking information from database. Last two days we got stuck. Currently we are using HTTPConnector to get and insert information. But we could not figure out how to match different users' schedules.
 
Remains to be done : We will get the data of the schedules and find a way to compare the schedules. We might change the database connection API to JSON.
Group members' contributions:



-WelcomePage class ==> Mehmet Ali Altuntas

-MainUserPage class ==> Kaan Sancak and Berk Mandirioglu

-SignIn Class(We wrote the class name wrong. It supposed to be SignUp) ==> Kaan Sancak

-BackgroundTask  Class==> Kaan Sancak and Berk Mandiricioglu

-MyUser Class ==> Mehmet Ali Altuntas and Berk Mandiracioglu

-More Information Class ==> Mehmet Ali Altuntas and Ozkan Tugberk Kartal

-Login Activity Class ==> Berk Mandiracioglu and Kaan Sancak

-SignUpRequest Class ==>  Kaan Sancak

-LoginRequest ==> Kaan Sancak

-frament_schedule Class ==> Mehmet Ali Altuntas and Ozkan Tugberk Kartal

-UserFragment Class ==> Kaan Sancak and Berk Mandiracioglu

-Xml file ==> Kaan Sancak and Mehmet Ali Altuntas and Berk Mandiracioglu


